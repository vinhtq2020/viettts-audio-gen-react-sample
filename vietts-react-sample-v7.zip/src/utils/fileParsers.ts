import * as pdfjsLib from "pdfjs-dist";
import mammoth from "mammoth";

pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

export interface ParsedPage {
  pageNum: number;
  text: string;
  charCount: number;
}

export interface ParsedDocument {
  title: string;
  pages: ParsedPage[];
  totalPages: number;
  batchSize: number;
}

const PAGE_SIZE = 3000;
const BATCH_SIZE = 10;

export async function parsePDF(file: File): Promise<ParsedDocument> {
  const arrayBuffer = await file.arrayBuffer();
  const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;

  const pages: ParsedPage[] = [];
  for (let i = 1; i <= pdf.numPages; i++) {
    const page = await pdf.getPage(i);
    const textContent = await page.getTextContent();
    const text = textContent.items
      .map((item: any) => item.str)
      .join(" ")
      .replace(/\s+/g, " ")
      .trim();

    pages.push({ pageNum: i, text, charCount: text.length });
  }

  return {
    title: file.name.replace(".pdf", ""),
    pages,
    totalPages: pdf.numPages,
    batchSize: BATCH_SIZE,
  };
}

export async function parseWord(file: File): Promise<ParsedDocument> {
  const arrayBuffer = await file.arrayBuffer();
  const result = await mammoth.extractRawText({ arrayBuffer });
  // Mammoth extractRawText() giữ xuống dòng giữa các paragraph.
  // Chỉ chuẩn hóa line ending / khoảng trắng thừa, tuyệt đối không đổi \n thành space.
  const fullText = result.value
    .replace(/\r\n/g, "\n")
    .replace(/\r/g, "\n")
    .replace(/[ \t]+\n/g, "\n")
    .replace(/\n[ \t]+/g, "\n")
    .replace(/\n{4,}/g, "\n\n\n")
    .trim();

  const pages: ParsedPage[] = [];
  let remaining = fullText;
  let pageNum = 1;

  while (remaining.length > 0) {
    let cutAt = remaining.lastIndexOf("\n\n", PAGE_SIZE);
    if (cutAt === -1) cutAt = remaining.lastIndexOf(". ", PAGE_SIZE);
    if (cutAt === -1) cutAt = Math.min(PAGE_SIZE, remaining.length);

    const pageText = remaining.slice(0, cutAt).trim();
    if (pageText)
      pages.push({ pageNum, text: pageText, charCount: pageText.length });

    remaining = remaining.slice(cutAt).trim();
    pageNum++;
  }

  return {
    title: file.name.replace(/\.(docx|doc)$/i, ""),
    pages,
    totalPages: pages.length,
    batchSize: BATCH_SIZE,
  };
}

export async function parseTXT(file: File): Promise<ParsedDocument> {
  const text = await file.text();
  const pages: ParsedPage[] = [];
  let remaining = text;
  let pageNum = 1;

  while (remaining.length > 0) {
    let cutAt = remaining.lastIndexOf("\n\n", PAGE_SIZE);
    if (cutAt === -1) cutAt = remaining.lastIndexOf(". ", PAGE_SIZE);
    if (cutAt === -1) cutAt = Math.min(PAGE_SIZE, remaining.length);

    const pageText = remaining.slice(0, cutAt).trim();
    if (pageText)
      pages.push({ pageNum, text: pageText, charCount: pageText.length });

    remaining = remaining.slice(cutAt).trim();
    pageNum++;
  }

  return {
    title: file.name.replace(/\.(txt|md)$/i, ""),
    pages,
    totalPages: pages.length,
    batchSize: BATCH_SIZE,
  };
}

export async function parseDocument(file: File): Promise<ParsedDocument> {
  const name = file.name.toLowerCase();
  if (name.endsWith(".pdf")) return parsePDF(file);
  if (name.endsWith(".docx") || name.endsWith(".doc")) return parseWord(file);
  if (name.endsWith(".txt") || name.endsWith(".md")) return parseTXT(file);
  throw new Error("Định dạng không hỗ trợ. Chỉ: .pdf, .docx, .txt, .md");
}
